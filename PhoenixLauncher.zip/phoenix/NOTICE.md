Phoenix Launcher, PojavLauncher (https://github.com/PojavLauncherTeam/PojavLauncher)
tabanlı bir türev çalışmadır. PojavLauncher LGPL-3.0 lisanslıdır: fork'unuzdaki
LICENSE dosyasını ve telif bildirimlerini silmeyin, kaynak kodunu açık tutun.
Minecraft, Mojang/Microsoft'un tescilli markasıdır; bu proje resmî değildir.
Oyunu oynamak için satın alınmış bir Minecraft Java Edition hesabı gerekir.
