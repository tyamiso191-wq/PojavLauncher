# Phoenix Launcher (PojavLauncher tabanlı)

## Ne yapar?
PojavLauncher'ın gerçek altyapısını (Java çalışma ortamı, LWJGL, GL katmanı, oyun içi
dokunmatik/klavye/fare kontrolleri, Microsoft girişi, sürüm ve mod yükleyici kurulumu)
aynen korur. Bu pakette Phoenix görünümü var: siyah/neon mor renk paleti, kara delik logosu,
"Phoenix Launcher" adı.

## APK nasıl çıkar? (telefondan da yapılır)
1. GitHub'da https://github.com/PojavLauncherTeam/PojavLauncher sayfasında **Fork** yapın.
2. Bu ZIP'in içindeki `phoenix_overlay` klasörünü ve `.github/workflows/phoenix-theme.yml`
   dosyasını fork'unuza yükleyin (Add file > Upload files).
3. Fork'unuzda **Actions > Phoenix temasını uygula > Run workflow**. Tema commit edilir.
4. Aynı Actions sekmesinde PojavLauncher'ın kendi build workflow'u çalışır (yoksa
   "I understand my workflows, go ahead and enable them" ile etkinleştirin).
   Bitince **Artifacts** altından APK'yı indirin.

## Dürüst durum listesi
- Çalışır (PojavLauncher'dan): oyun başlatma, kontroller, Java 8/17/21, Microsoft girişi,
  Fabric/Forge kurulumu, sürüm indirme.
- Phoenix'te yapıldı: renk paleti, uygulama adı, ikon/logo.
- **Yapılmadı:** ekranların tamamen yeniden tasarlanması (layout'lar), Modrinth/CurseForge
  mod tarayıcı ekranı, NeoForge, MobileGlues, Meteor Client doğrulaması. Bunlar
  PojavLauncher'ın gerçek kod yapısını görmeden güvenli yazılamaz.
- Hiçbir şey cihazda test edilmedi; renk dönüşümü otomatik olduğu için bazı yerler
  uyumsuz görünebilir.
- API anahtarı gömülmedi.

## Sonraki adım (tam arayüz için)
Fork'unuzu GitHub'dan "Download ZIP" ile indirip bana yükleyin; layout'ları ve
ekranları gerçek kodun üzerine yazarak Phoenix arayüzünü tamamlayabilirim.
