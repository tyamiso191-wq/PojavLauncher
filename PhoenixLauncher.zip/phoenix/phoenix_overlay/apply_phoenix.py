#!/usr/bin/env python3
"""Phoenix Launcher teması: PojavLauncher fork'unun kök klasöründe çalıştırın."""
import os, re, shutil, colorsys, sys, glob
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.getcwd()
mod = next((m for m in ("app_pojavlauncher", "app") if os.path.isdir(os.path.join(ROOT, m, "src", "main", "res"))), None)
if not mod: sys.exit("HATA: PojavLauncher kök klasöründe değilsiniz (app_pojavlauncher bulunamadı).")
res = os.path.join(ROOT, mod, "src", "main", "res")

def remap(m):
    h = m.group(1)
    if len(h) == 6: a, rgb = "", h
    else: a, rgb = h[:2], h[2:]
    r, g, b = (int(rgb[i:i+2], 16)/255 for i in (0, 2, 4))
    hh, s, v = colorsys.rgb_to_hsv(r, g, b)
    if s >= 0.35 and v >= 0.25: new = "B000FF" if v > 0.6 else "7928CA"
    elif v < 0.12: new = "09090D"
    elif v < 0.35 and s < 0.35: new = "191923"
    elif v > 0.85 and s < 0.15: new = "FFFFFF"
    elif s < 0.2 and v >= 0.45: new = "A5A5B5"
    else: return m.group(0)
    return ">#" + a + new + "<"

n = 0
for f in glob.glob(os.path.join(res, "values*", "colors.xml")):
    t = open(f, encoding="utf-8").read()
    t2 = re.sub(r">#([0-9A-Fa-f]{8}|[0-9A-Fa-f]{6})<", remap, t)
    if t2 != t: open(f, "w", encoding="utf-8").write(t2); n += 1
print(f"Renkler güncellendi: {n} dosya")

for f in glob.glob(os.path.join(res, "values*", "strings.xml")):
    t = open(f, encoding="utf-8").read()
    t2 = re.sub(r'(<string name="app_name"[^>]*>).*?(</string>)', r"\1Phoenix Launcher\2", t)
    if t2 != t: open(f, "w", encoding="utf-8").write(t2)

# ikonlar + renk kaynakları
src = os.path.join(HERE, "overlay", "res")
for d, _, files in os.walk(src):
    dst = os.path.join(res, os.path.relpath(d, src)); os.makedirs(dst, exist_ok=True)
    for fn in files: shutil.copy(os.path.join(d, fn), os.path.join(dst, fn))
# eski adaptive ikon varyantlarını temizle (bizimkiyle çakışmasın)
for f in glob.glob(os.path.join(res, "mipmap-anydpi*", "ic_launcher*.xml")):
    if "anydpi-v26" not in f: os.remove(f)
for f in glob.glob(os.path.join(res, "drawable*", "ic_launcher*")): os.remove(f)
print("Phoenix teması uygulandı. Şimdi commit/push yapın; PojavLauncher'ın kendi workflow'u APK'yı üretir.")
